package com.example.sporty;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.maps.model.LatLng;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Inicio extends AppCompatActivity {
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private TextView tvActivity;
    private Button btnEmpezar;
    private Button btnAcabar;
    private String activityType;
    private long startTime;
    private LatLng inicio;
    private LatLng fin;
    private float totalDistance;
    private BaseDatos mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        tvActivity = findViewById(R.id.textView);
        btnEmpezar = findViewById(R.id.button);
        btnAcabar = findViewById(R.id.button2);

        btnEmpezar.setEnabled(true);
        btnAcabar.setEnabled(false);

        mDbHelper = new BaseDatos(this, "entrenos.db", null, 1);


        activityType = getIntent().getStringExtra("activity_type");
        tvActivity.setText("Actividad: " + activityType);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                if (inicio != null) {
                    totalDistance += distanceBetweenCoordinates(inicio.latitude, inicio.longitude, location.getLatitude(), location.getLongitude());
                }
                inicio = new LatLng(location.getLatitude(), location.getLongitude());
            }
        };
        btnEmpezar.setOnClickListener(v -> empezar());
        btnAcabar.setOnClickListener(v -> end());

        checkLocationPermission();
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void empezar() {
        startTime = System.currentTimeMillis();
        totalDistance = 0;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1, locationListener);
        }
        inicio = getLocation();

        btnEmpezar.setEnabled(false);
        btnAcabar.setEnabled(true);
    }

    private void end() {
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationManager.removeUpdates(locationListener);
        }

        float kilometers = totalDistance / 1000;
        float calories = calculateCalories(duration, kilometers);

        fin = getLocation();

        saveTrainingSession(startTime, endTime, inicio, fin, kilometers, calories);

        openActivity();

        btnEmpezar.setEnabled(true);
        btnAcabar.setEnabled(false);
    }

    private float calculateCalories(long duration, float kilometers) {
        return kilometers * 60; // Calorías quemadas por kilómetro
    }
    private void openActivity() {
        Intent intent = new Intent(Inicio.this, Registro.class);
        startActivity(intent);
    }
    
   
    private void saveTrainingSession(long startTime, long endTime, LatLng inicio, LatLng fin, float kilometers, float calories) {

        System.out.println("Actividad: " + activityType);
        System.out.println("Inicio: " + new Date(startTime).toString() + " - Coordenadas: (" + inicio.latitude + ", " + inicio.longitude + ")");
        System.out.println("Fin: " + new Date(endTime).toString() + " - Coordenadas: (" + fin.latitude + ", " + fin.longitude + ")");
        System.out.println("Kilómetros: " + kilometers);
        System.out.println("Calorías: " + calories);

        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String fechaActual = sdf.format(new Date());

        // Crear un nuevo objeto ContentValues para almacenar los valores a insertar
        ContentValues values = new ContentValues();
        values.put(BaseDatos.COLUMN_ACTIVITY_TYPE, activityType);
        values.put(BaseDatos.COLUMN_START_TIME, startTime);
        values.put(BaseDatos.COLUMN_END_TIME, endTime);
        values.put(BaseDatos.COLUMN_DISTANCE, kilometers);
        values.put(BaseDatos.COLUMN_DATE, fechaActual); // Fecha actual
        values.put(BaseDatos.COLUMN_CALORIES, calories);

        // Insertar la nueva fila en la tabla
        long newRowId = db.insert(BaseDatos.TABLE_NAME, null, values);

        // Verificar si la inserción fue exitosa
        if (newRowId != -1) {
            // Inserción exitosa
            System.out.println("Datos de sesión de entrenamiento guardados en la base de datos.");
        } else {
            // Ocurrió un error durante la inserción
            System.out.println("Error al guardar los datos de sesión de entrenamiento en la base de datos.");
        }
    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                empezar();
            }
        }
    }


    private LatLng getLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            Location location = getLastKnownLocation();
            if (location != null) {
                return new LatLng(location.getLatitude(), location.getLongitude());
            }
        }
        return null;
    }




    private Location getLastKnownLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Manejar el caso en el que no se hayan otorgado los permisos necesarios
            return null;
        }
        Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (lastKnownLocation == null) {
            lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }
        return lastKnownLocation;
    }


    private float distanceBetweenCoordinates(double startLat, double startLng, double endLat, double endLng) {
        float[] results = new float[1];
        Location.distanceBetween(startLat, startLng, endLat, endLng, results);
        return results[0];
    }
}



